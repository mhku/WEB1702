<?php
  echo "<h1>hello php</h1>";
?>