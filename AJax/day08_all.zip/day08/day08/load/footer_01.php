<?php
 //全站中每个页面都有页尾内容
 header("content-type:text/html;charset=utf-8");
?>
<hr />
<p class="text-center">版权所有@ 达内科技</p>