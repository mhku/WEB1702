<?php
  //全站中每个页面的页头内容
  //1:修改响应头数据格式 text/html
  header("content-type:text/html;charset=utf-8");
?>
<ul class="nav">
    <li><a href="#">首页</a></li>
    <li><a href="#">新闻</a></li>
    <li><a href="#">动态</a></li>
    <li><a href="#">产品</a></li>
</ul>