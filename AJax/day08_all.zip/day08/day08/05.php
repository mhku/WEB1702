<?php
 header("content-type:text/plain;charset=utf-8");
 echo "hello";
?>