<!doctype html>
<html>
  <head>
    <title>hello world</title>
  </head>
  <body>
    <?php
	  $msg = 'HelloWorld';
	  echo($msg);
	  echo('<br />');
	  $msg = "HelloPhp";
	  echo($msg);

	?>
  </body>
</html>