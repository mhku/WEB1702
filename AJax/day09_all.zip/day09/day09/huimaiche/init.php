<?php
 $conn = mysqli_connect("127.0.0.1","root","","huimaiche");
 mysqli_query($conn,"SET NAMES UTF8");