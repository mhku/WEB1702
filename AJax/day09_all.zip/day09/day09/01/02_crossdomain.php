<?php
  header("content-type:application/javascript;charset=utf-8");
  echo "callback('hello')";
?>