var user = require("./8_module_user");
//使用模块  8_module_user
console.log(user.userCount);
user.userLogout();
console.log(user.);

