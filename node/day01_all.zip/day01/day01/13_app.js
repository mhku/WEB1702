var au = require("./12_ArrayUtil");
var list = [7,8,9];
console.log(au.sum(list));
console.log(au.avg(list));