//nodejs全局模块 global
console.log(global);