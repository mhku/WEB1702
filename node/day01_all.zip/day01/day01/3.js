var msg = "hello world";
console.log(msg);