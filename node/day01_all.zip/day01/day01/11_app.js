//引入Circle模块,-->并且创建Circle模块实例
var c = require("./10_Circle");
console.log(c);
console.log(c.size(3));
console.log(c.perimeter(3));
