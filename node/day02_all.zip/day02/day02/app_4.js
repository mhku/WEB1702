//引入放置在node_modules目录目录模块
const c = require("circle");
console.log(c.size(3));
console.log(c.perimeter(3));
const rectangle = require("rectangle");

