module.exports.age = 20;
module.exports.uname = 'qiangdong';