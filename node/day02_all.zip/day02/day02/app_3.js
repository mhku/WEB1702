const m6 = require("m6");
console.log(m6);