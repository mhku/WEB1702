//引入一个目录模块
const m4 = require("./m4");
console.log(m4);

//引入一个目录模块
const m5 = require("./m5");
console.log(m5);

