const m = require("6_module6");
console.log(m);