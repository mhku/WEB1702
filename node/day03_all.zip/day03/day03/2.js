//(function(exports,require,module,__filename,__dirname){
//m对象名称-->
var m = require("./1");
m.stop();
//}

